"""
Tiny combinational logic simulator producing WaveDrom JSON.
Usage:
  python digitalsim.py path/to/circuit.net [--out out.json]
This script reads a simple text-based .net file describing a digital
logic circuit, simulates it based on a set of inputs (stimulus),
and generates a JSON file that can be used with a waveform viewer
like wavedrom.com.
"""

import sys
import argparse
import re  # Used for regular expressions to parse the GATES section
import json
from pathlib import Path
from typing import List, Dict, Any, Tuple, Set
from dataclasses import dataclass, field

# Data Structures: We define custom "types" to store our circuit data in an organized way.


@dataclass
class Gate:
    # Represents a single logic gate
    output_wire: str
    gate_type: str
    input_wires: List[str]


@dataclass
class Netlist:
    # Represents the entire parsed circuit netlist.
    inputs: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)
    gates: List[Gate] = field(default_factory=list)
    stimulus: List[Tuple[int, List[int]]] = field(default_factory=list)
    # This set will keep track of every signal name ever mentioned
    # (inputs, outputs, or internal wires like 'T1')
    all_signals: Set[str] = field(default_factory=set)


# Core Functions


def parse_netlist(text: str) -> Netlist:
    """
    Parses the netlist text into a structured Netlist object.
    This function reads the .net file text line-by-line, processing it
    in sections: INPUTS, OUTPUTS, GATES, and STIMULUS.
    """
    netlist = Netlist()

    # Clean up the text: remove whitespace and comments
    all_lines = text.splitlines()
    clean_lines = []
    for line in all_lines:
        stripped_line = line.strip()
        if stripped_line and not stripped_line.startswith("#"):
            clean_lines.append(stripped_line)
    if not clean_lines:
        raise ValueError("Netlist file is empty or contains only comments.")

    # We expect sections in a specific order.
    EXPECTED_SECTIONS = ["INPUTS", "OUTPUTS", "GATES", "STIMULUS"]
    current_section_index = 0
    current_line_index = 0
    while current_line_index < len(clean_lines):
        if current_section_index >= len(EXPECTED_SECTIONS):
            break
        current_section_name = EXPECTED_SECTIONS[current_section_index]
        line = clean_lines[current_line_index]

        if line.startswith(f"{current_section_name}:"):
            # INPUTS Section
            if current_section_name == "INPUTS":
                # Get the content after "INPUTS:"
                _, content = line.split(":", 1)
                netlist.inputs = content.strip().split()
                if not netlist.inputs:
                    raise ValueError("INPUTS section cannot be empty.")
                # Add these signals to our master list
                netlist.all_signals.update(netlist.inputs)

            # OUTPUTS Section
            elif current_section_name == "OUTPUTS":
                _, content = line.split(":", 1)
                netlist.outputs = content.strip().split()
                if not netlist.outputs:
                    raise ValueError("OUTPUTS section cannot be empty.")
                netlist.all_signals.update(netlist.outputs)

            # GATES Section
            elif current_section_name == "GATES":
                current_line_index += 1  # Move to the first gate line
                # This "regular expression" defines the pattern for a valid gate
                GATE_SYNTAX_PATTERN = re.compile(
                    r"^(?P<out>\w+)\s*=\s*(?P<type>AND|OR|XOR|NOT)\s*\((?P<args>[\w\s,]+)\)$"
                )
                # This creates a regular expression pattern.
                # Think of it as a blueprint for text that the program uses to validate and parse the lines in the GATES: section of your netlist file.
                # The function re.compile() takes that blueprint string and turns it into a highly efficient "pattern object" that can be used over and over to check other strings.
                while current_line_index < len(clean_lines) and not clean_lines[
                    current_line_index
                ].startswith("STIMULUS:"):

                    gate_line = clean_lines[current_line_index]
                    match = GATE_SYNTAX_PATTERN.match(gate_line)
                    if not match:
                        raise ValueError(f"Invalid gate syntax: '{gate_line}'")
                    # Extract the named groups from our regex pattern
                    gate_type = match.group("type")
                    output_wire = match.group("out")
                    args_string = match.group("args")  # e.g., "A, B"
                    # Split the arguments string (e.g., "A, B") into a list
                    arg_list = args_string.split(",")
                    # Clean up whitespace from each argument
                    input_wires = []
                    for arg in arg_list:
                        input_wires.append(arg.strip())
                    # Validation for this gate
                    if gate_type == "NOT" and len(input_wires) != 1:
                        raise ValueError(
                            f"Gate {gate_type} ({output_wire}) needs 1 input, got {len(input_wires)}"
                        )
                    if gate_type in ["AND", "OR", "XOR"] and len(input_wires) != 2:
                        raise ValueError(
                            f"Gate {gate_type} ({output_wire}) needs 2 inputs, got {len(input_wires)}"
                        )
                    # Add this gate to our netlist
                    netlist.gates.append(Gate(output_wire, gate_type, input_wires))
                    # Add its signals to the master list
                    netlist.all_signals.add(output_wire)
                    netlist.all_signals.update(input_wires)
                    current_line_index += 1
                current_line_index -= (
                    1  # Rewind one line so we can "see" the STIMULUS header
                )
            # STIMULUS Section
            elif current_section_name == "STIMULUS":
                current_line_index += 1  # Move to the first stimulus line
                last_time_step = -1
                while current_line_index < len(clean_lines):
                    stimulus_line = clean_lines[current_line_index]
                    parts = stimulus_line.split()
                    try:
                        time_step = int(parts[0])
                        # Get all remaining parts as input value strings
                        input_values_as_strings = parts[1:]
                        # Convert each one to an integer
                        input_values = []
                        for val_str in input_values_as_strings:
                            input_values.append(int(val_str))
                    except (ValueError, IndexError):
                        raise ValueError(f"Invalid stimulus line: '{stimulus_line}'")
                    # Validation for this stimulus line
                    if time_step <= last_time_step:
                        raise ValueError("Stimulus times must be strictly increasing.")
                    if len(input_values) != len(netlist.inputs):
                        raise ValueError(
                            f"Stimulus at time {time_step}: expected {len(netlist.inputs)} "
                            f"input values, but found {len(input_values)}."
                        )
                    netlist.stimulus.append((time_step, input_values))
                    last_time_step = time_step
                    current_line_index += 1

                current_line_index -= 1  # Rewind for the outer loop
            # We've finished this section, move to the next
            current_section_index += 1
        current_line_index += 1
    if current_section_index != len(EXPECTED_SECTIONS):
        raise ValueError(
            f"Missing required section: {EXPECTED_SECTIONS[current_section_index]}"
        )

    # Final Validation to make sure every gate input corresponds to a real signal
    for gate in netlist.gates:
        for input_wire in gate.input_wires:
            if input_wire not in netlist.all_signals:
                raise ValueError(
                    f"Signal '{input_wire}' (used by gate {gate.output_wire}) "
                    "was never defined as an INPUT or a gate OUTPUT."
                )
    return netlist


def eval_gate(gate_type: str, inputs: List[int]) -> int:
    """
    Evaluates the output of a single logic gate (e.g., AND, OR).
    """
    if gate_type == "AND":
        return 1 if (inputs[0] == 1 and inputs[1] == 1) else 0
    if gate_type == "OR":
        return 1 if (inputs[0] == 1 or inputs[1] == 1) else 0
    if gate_type == "XOR":
        return 1 if (inputs[0] != inputs[1]) else 0
    if gate_type == "NOT":
        return 1 if (inputs[0] == 0) else 0
    raise ValueError(f"Unknown gate type: {gate_type}")


def _find_gate_evaluation_order(netlist: Netlist) -> List[Gate]:
    """
    Finds a safe order to evaluate gates using a topological sort.
    This is crucial for circuits like "Y = NOT(T)" where "T" is the
    output of another gate. We *must* evaluate T's gate first.
    This function implements Kahn's algorithm for topological sorting.
    """
    # Build the dependency graph
    all_gate_outputs = {gate.output_wire for gate in netlist.gates}

    # 'gate_dependency_count' (or "in-degree") ; Maps: gate_output_wire -> how many *other gates* it depends on
    gate_dependency_count: Dict[str, int] = {g.output_wire: 0 for g in netlist.gates}
    # 'signal_to_gates_map' (or "adjacency list") ; Maps: signal_name -> list of GATES that use this signal as an input
    signal_to_gates_map: Dict[str, List[Gate]] = {
        sig: [] for sig in netlist.all_signals
    }
    for gate in netlist.gates:
        for input_wire in gate.input_wires:
            # This gate depends on 'input_wire'. So, add this gate to the list of things that 'input_wire' feeds into.
            signal_to_gates_map[input_wire].append(gate)
            # If that input wire is *itself* the output of another gate then this gate has a dependency on that other gate.
            if input_wire in all_gate_outputs:
                gate_dependency_count[gate.output_wire] += 1

    # Run the topological sort
    # Find all gates that have *zero* dependencies on other gates.
    ready_to_evaluate_queue = [
        g for g in netlist.gates if gate_dependency_count[g.output_wire] == 0
    ]
    evaluation_order: List[Gate] = []
    while ready_to_evaluate_queue:
        # Take a gate that's ready to be evaluated
        current_gate = ready_to_evaluate_queue.pop(0)
        evaluation_order.append(current_gate)
        # Find all gates that depend on this one's output
        output_signal_name = current_gate.output_wire
        for next_gate in signal_to_gates_map[output_signal_name]:
            # We just "satisfied" one of 'next_gate's dependencies
            gate_dependency_count[next_gate.output_wire] -= 1
            # If all of 'next_gate's dependencies are met, it's ready!
            if gate_dependency_count[next_gate.output_wire] == 0:
                ready_to_evaluate_queue.append(next_gate)

    # Final check. If our final order doesn't include all gates, it means there was a cycle (e.g., A feeds B, B feeds A).
    if len(evaluation_order) != len(netlist.gates):
        raise ValueError("Circuit contains a combinational loop (cycle).")
    return evaluation_order


def simulate(netlist: Netlist) -> Dict[str, str]:
    """
    Simulates the circuit for all stimulus steps.
    """
    # Get the safe order to evaluate the gates
    gate_evaluation_order = _find_gate_evaluation_order(netlist)
    # We only need to record the final waveforms for inputs and outputs
    signals_to_record = netlist.inputs + netlist.outputs
    # This dictionary will store the growing waveform string for each signal e.g., "A": "0011", "B": "0101"
    waveform_strings: Dict[str, str] = {name: "" for name in signals_to_record}

    # Simulation Loop
    for time_step, input_values in netlist.stimulus:
        # This dictionary holds the value (0 or 1) of *every* signal for just this *one* moment in time.
        current_time_step_values: Dict[str, int] = {}
        # Set primary input values from the stimulus
        for i, input_name in enumerate(netlist.inputs):
            current_time_step_values[input_name] = input_values[i]
        # Evaluate all gates in the correct (topological) order
        for gate in gate_evaluation_order:
            # Look up the values for this gate's inputs
            input_values_for_this_gate = []
            for input_wire_name in gate.input_wires:
                value = current_time_step_values[input_wire_name]
                input_values_for_this_gate.append(value)
            # Calculate this gate's output
            output_value = eval_gate(gate.gate_type, input_values_for_this_gate)
            # Store it so other gates can use it
            current_time_step_values[gate.output_wire] = output_value
        # Record the final values of tracked signals (inputs and outputs)
        for signal_name in signals_to_record:
            # Append the value (as a '0' or '1' string) to the waveform
            value_char = str(current_time_step_values[signal_name])
            waveform_strings[signal_name] += value_char
    return waveform_strings


def to_wavedrom_json(netlist: Netlist, waveform_strings: Dict[str, str]) -> str:
    """
    Formats the simulation results into a compact WaveDrom JSON string.
    """
    wavedrom_signal_list = []
    # Add inputs first, in their declared order
    for name in netlist.inputs:
        wavedrom_signal_list.append({"name": name, "wave": waveform_strings[name]})
    # Add outputs next, in their declared order
    for name in netlist.outputs:
        wavedrom_signal_list.append({"name": name, "wave": waveform_strings[name]})
    # Create the final JSON object structure
    wavedrom_data = {"signal": wavedrom_signal_list}
    # Convert the Python dictionary to a compact JSON string
    return json.dumps(wavedrom_data)


def main(command_line_args: List[str]) -> int:
    """Main entry point for the script."""
    # This setup parses arguments like "and2.net" from the command line
    parser = argparse.ArgumentParser(description="Tiny digital logic simulator")
    parser.add_argument("netlist", help=".net file path")
    parser.add_argument("--out", "-o", help="Optional output JSON file path")
    args = parser.parse_args(command_line_args)
    try:
        # Read
        input_file_path = Path(args.netlist)
        netlist_text = input_file_path.read_text()
        # Parse
        parsed_netlist = parse_netlist(netlist_text)
        # Simulate
        simulation_results = simulate(parsed_netlist)
        # Format
        json_output_string = to_wavedrom_json(parsed_netlist, simulation_results)
        # Write
        output_file_path_str = args.out
        if not output_file_path_str:
            output_file_path_str = str(input_file_path.with_suffix(".json"))
        output_file_path = Path(output_file_path_str)
        output_file_path.write_text(json_output_string + "\n")
        print(f"Successfully generated waveform file: {output_file_path}")
        return 0

    except FileNotFoundError:
        print(f"Error: Input file not found at '{args.netlist}'", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"Error processing netlist: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
